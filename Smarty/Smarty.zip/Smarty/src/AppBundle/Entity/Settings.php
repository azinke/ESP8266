<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Settings
 *
 * @ORM\Table(name="settings")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\SettingsRepository")
 */
class Settings
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="ip_adress", type="string", length=30, unique=true)
     * @Assert\NotBlank(
     * message = "Fill out this field."
     * )
     * @Assert\Length(
     * min=7,
     * max=15,
     * minMessage = "Invalid IP adress",
     * maxMessage = "Check the IP adresse please!"
     * )
     */
    private $ipAdress;

    /**
     * @var int
     *
     * @ORM\Column(name="port", type="integer")
     *
     * @Assert\NotBlank(
     * message = "Fill out this field."
     * )
     */
    private $port;

    /**
     * @var int
     *
     * @ORM\Column(name="mcu", type="integer")
     *
     * @Assert\NotBlank(
     * message = "Fill out this field."
     * )
     */
    private $mcu;

    /**
     * @var int
     *
     * @ORM\Column(name="max_output", type="integer")
     *
     * @Assert\NotBlank(
     * message = "Fill out this field."
     * )
     */
    private $maxOutput;

    /**
     * @var int
     *
     * @ORM\Column(name="max_input", type="integer")
     *
     * @Assert\NotBlank(
     * message = "Fill out this field."
     * )
     */
    private $maxInput;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
    * Constructor
    */
    public function __construct(){
      //$this->createdAt = \new DateTime();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set ipAdress
     *
     * @param string $ipAdress
     *
     * @return Settings
     */
    public function setIpAdress($ipAdress)
    {
        $this->ipAdress = $ipAdress;

        return $this;
    }

    /**
     * Get ipAdress
     *
     * @return string
     */
    public function getIpAdress()
    {
        return $this->ipAdress;
    }

    /**
     * Set port
     *
     * @param integer $port
     *
     * @return Settings
     */
    public function setPort($port)
    {
        $this->port = $port;

        return $this;
    }

    /**
     * Get port
     *
     * @return int
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * Set mcu
     *
     * @param integer $mcu
     *
     * @return Settings
     */
    public function setMcu($mcu)
    {
        $this->mcu = $mcu;

        return $this;
    }

    /**
     * Get mcu
     *
     * @return int
     */
    public function getMcu()
    {
        return $this->mcu;
    }

    /**
     * Set maxOutput
     *
     * @param integer $maxOutput
     *
     * @return Settings
     */
    public function setMaxOutput($maxOutput)
    {
        $this->maxOutput = $maxOutput;

        return $this;
    }

    /**
     * Get maxOutput
     *
     * @return int
     */
    public function getMaxOutput()
    {
        return $this->maxOutput;
    }

    /**
     * Set maxInput
     *
     * @param integer $maxInput
     *
     * @return Settings
     */
    public function setMaxInput($maxInput)
    {
        $this->maxInput = $maxInput;

        return $this;
    }

    /**
     * Get maxInput
     *
     * @return int
     */
    public function getMaxInput()
    {
        return $this->maxInput;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Settings
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Settings
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}
