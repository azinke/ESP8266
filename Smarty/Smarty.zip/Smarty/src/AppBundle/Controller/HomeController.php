<?php
  namespace AppBundle\Controller;

  use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
  use Symfony\Bundle\FrameworkBundle\Controller\Controller;
  use Symfony\Component\HttpFoundation\Response;
  use Symfony\Component\HttpFoundation\Request;

  use AppBundle\Entity\Settings;
  use AppBundle\Entity\Sensor;
  use AppBundle\Entity\Equipment;
  use AppBundle\Entity\Console;

  use AppBundle\Form\SettingsType;
  use AppBundle\Form\SensorType;
  use AppBundle\Form\EquipmentType;
  use AppBundle\Form\ConsoleType;

  class HomeController extends Controller{

    /**
    * @Route("/app/{_locale}/home.{_format}", name="homepage", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function homepageAction(){
      $sensors = $this->getDoctrine()->getRepository("AppBundle:Sensor")->findByIsDeleted(false);
      $eq = $this->getDoctrine()->getRepository("AppBundle:Equipment")->findByIsDeleted(false);
      $settings = $this->getDoctrine()->getRepository("AppBundle:Settings")->findOneById(1);
      if(!$settings) return $this->redirectToRoute("settings");
      $now = new \DateTime();
      return $this->render("root.html.twig", array(
        'sensors' => $sensors,
        'eq' => $eq,
        'settings' => $settings,
        'now' => $now,
      ));
    }

    /**
    * @Route("/app/{_locale}/settings.{_format}", name="settings", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function settingsAction(Request $request){
      $em = $this->getDoctrine()->getManager();
      $settings = $this->getDoctrine()->getRepository("AppBundle:Settings")->findOneById(1);
      if(!$settings){
        $settings = new Settings();
      }

      $form = $this->createForm(SettingsType::class, $settings);
      $form->handleRequest($request);
      if($form->isSubmitted() && $form->isValid()){
        $settings = $form->getData();
        $settings->setCreatedAt(new \DateTime());
        $em->persist($settings);
        $em->flush();
      }
      return $this->render("default/settings.html.twig", array(
        'form' => $form->createView(),
      ));
    }

    /**
    * @Route("/")
    */
    public function rootAction(){
      return $this->redirectToRoute("index");
    }

    /**
    * @Route("/logout", name="exit")
    */
    public function exitAction(){

    }

    /**
    * @Route("/{_locale}/index.{_format}", name="index", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function indexAction(){

      #render template
      return $this->render("index.html.twig");
    }

    /**
    * @Route("/app/{_locale}/sensor.{_format}/{id}", name="addSensor", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function addSensorAction(Request $request, $id = 0){
      if($id <= 0) $sensor = new Sensor();
      else {
        $sensor = $this->getDoctrine()->getRepository("AppBundle:Sensor")->findOneById($id);
      }
      $informations = "";

      $em = $this->getDoctrine()->getManager();
      $form = $this->createForm(SensorType::class, $sensor);
      $form->handleRequest($request);

      $settings = $this->getDoctrine()->getRepository("AppBundle:Settings")->findOneById(1);
      if(!$settings){
        // redirect to settings configuration
        return $this->redirectToRoute("settings");
      }

      if($form->isSubmitted() && $form->isValid()){
        $sensor = $form->getData();
        if($sensor->getInput() < $settings->getMaxInput()){
          $sensor->setCreatedAt(new \DateTime());

          if($id <= 0 ) $em->persist($sensor);
          $em->flush();
          // return ...
          return $this->redirectToRoute("sensorsList");
        }else{ $informations = "Input limit violation !!!"; }
      }
      return $this->render("default/addSensor.html.twig", array(
        'form' => $form->createView(),
        'informations' => $informations
      ));
    }

    /**
    * @Route("/app/{_locale}/sensor_list.{_format}", name="sensorsList", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function sensorsListAction(){
      $em = $this->getDoctrine();
      $sensors = $this->getDoctrine()->getRepository("AppBundle:Sensor")->findByIsDeleted(false);

      return $this->render('default/sensorsList.html.twig', array(
        'sensors' => $sensors,
      ));
    }

    /**
    * @Route("/app/{_locale}/equipment.{_format}/{id}", name="addEquipment", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function addEquipmentAction(Request $request, $id = 0){
      if($id <= 0) $eq = new Equipment();
      else{
        $eq = $this->getDoctrine()->getRepository("AppBundle:Equipment")->findOneById($id);
      }
      $informations = "";

      $em = $this->getDoctrine()->getManager();
      $form = $this->createForm(EquipmentType::class, $eq);
      $form->handleRequest($request);

      $settings = $this->getDoctrine()->getRepository("AppBundle:Settings")->findOneById(1);
      if(!$settings){
        // redirect to settings configuration
        return $this->redirectToRoute("settings");
      }

      if($form->isSubmitted() && $form->isValid()){
        $eq = $form->getData();
        if($eq->getOutput() < $settings->getMaxOutput()){
          $eq->setCreatedAt(new \DateTime());

          if($id <= 0) $em->persist($eq);
          $em->flush();
          // return ...
          return $this->redirectToRoute("equipmentsList");
        }else{ $informations = "Output limit violation !!!"; }
      }
      return $this->render("default/addEquipment.html.twig", array(
        'form' => $form->createView(),
        'informations' => $informations
      ));
    }

    /**
    * @Route("/app/{_locale}/equipment_list.{_format}", name="equipmentsList", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function EquipmentsListAction(){
      $eq = $this->getDoctrine()->getRepository("AppBundle:Equipment")->findByIsDeleted(false);

      return $this->render('default/equipmentsList.html.twig', array(
        'equipments' => $eq,
      ));
    }

    /**
    * @Route("/app/{_locale}/_delete.{_format}/{type}/{id}", name="delete", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function deleteAction($type = 0, $id = 0){
      switch($type){
        case 1:{ // Delete a sensor
          if($id > 0){
            $em = $this->getDoctrine()->getManager();
            $sensor = $this->getDoctrine()->getRepository("AppBundle:Sensor")->findOneById($id);
            $sensor->setIsDeleted(true);
            $em->flush();
            return $this->redirectToRoute("sensorsList");
          }
          break;
        }
        case 2:{ // Delete an equipment
          if($id > 0){
            $em = $this->getDoctrine()->getManager();
            $eq = $this->getDoctrine()->getRepository("AppBundle:Equipment")->findOneById($id);
            $eq->setIsDeleted(true);
            $em->flush();
            return $this->redirectToRoute("equipmentsList");
          }
          break;
        }
        case 3:{ // DELETE DEFINETLY A SENSOR
          if($id > 0){
            $em = $this->getDoctrine()->getManager();
            $sensor = $this->getDoctrine()->getRepository("AppBundle:Sensor")->findOneById($id);
            $em->remove($sensor);
            $em->flush();
            return $this->redirectToRoute("sensorsList");
          }
          break;
        }
        case 4:{ // DELETE DEFINETLY AN EQUIPMENT
          if($id > 0){
            $em = $this->getDoctrine()->getManager();
            $eq = $this->getDoctrine()->getRepository("AppBundle:Equipment")->findOneById($id);
            $em->remove($eq);
            $em->flush();
            return $this->redirectToRoute("equipmentsList");
          }
          break;
        }
        default: return $this->redirectToRoute("homepage");
      }
    }

    /**
    * @Route("/app/{_locale}/save_logs.{_format}", name="savelogs", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function savelogsAction(Request $request){
      $log = new Console();
      $log->setAction($request->request->get('action'));
      $log->setCreatedAt(new \DateTime());

      $em = $this->getDoctrine()->getManager();
      $em->persist($log);
      $em->flush();
      return new Response("OK");
    }

    /**
    * @Route("/app/{_locale}/logs.{_format}", name="logs", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function logsAction(){
      $logs = $this->getDoctrine()->getRepository('AppBundle:Console')->findAll();
      return $this->render("default/logs.html.twig", array(
        'logs' => $logs,
      ));
    }

    /**
    * @Route("/app/{_locale}/about.{_format}", name="aboutUs", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function aboutUsAction(){
       return $this->render("default/aboutUs.html.twig");
    }

    /**
    * @Route("/app/{_locale}/iot.{_format}", name="iot", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function iotAction(){
       return $this->render("default/iot.html.twig");
    }

    /**
    * @Route("/app/{_locale}/chart.{_format}/{id}", name="rtlChart", defaults={"_format":"html", "_locale":"fr"},
    * requirements={
    * "_locale":"fr|en",
    * "_format":"html"
    * })
    */
    public function rtlChartAction( $id = 0 ){
       //return $this->render("default/iot.html.twig");
    }

  }
?>
