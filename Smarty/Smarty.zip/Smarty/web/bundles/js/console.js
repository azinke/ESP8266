$(document).ready(function(){

  /**
    Gateway for ajax request
  **/

  $.ajaxSetup({
      type: 'POST',
      url: "http://" + $("#terminal").attr("data-ip"),
      dataType: 'html',
      timeout: 60000,
      error: function(xhr, status, error) {
        var date = new Date();
        $("#terminal").append('<li class="red-text"><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Smarty server offline.'+ '   <span class="grey-text">On '+ date +'</span></li>');
      }
  });

  $('.equipment').on('change', function(){
    var gpioState = parseInt($(this).attr('data-state'));
    var gpioPin = parseInt($(this).attr('data-gpio'));

    gpioState ^= 1 ;
    $(this).attr('data-state',gpioState.toString());

    $.ajax({
      url: "http://" + $("#terminal").attr("data-ip") + "/dev",
      data: {
        gpio: gpioPin.toString(),
        state: gpioState.toString()
      },
      success: function(response){
        var date = new Date();
        $("#terminal").append('<li><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Ouput '+ gpioPin +' updated with success.'+ '   <span class="grey-text">On '+ date +'</span></li>');
        $.ajax({
          url: $(".console").attr("data-log-url"),
          data:{
            action: gpioPin.toString() + ':' +gpioState.toString()
          },
          success: function(){
            //
          }
        })
      }
    });
  });

  var readSensor = setInterval(function(){
    $.ajax({
        url: "http://" + $("#terminal").attr("data-ip") + "/sensor",
        data:{
          gpio: '0',
        },
        success: function(response){
          // Trigger the rigth switch
          //alert($(".equipment").attr('data-gpio'));
          var value = (parseInt(response)*3.3)/1023; // ceil(value).toString()
          $("#val").html(value.toString().substring(0, 5));
        }
    });
  }, 4000);

  /**
    Clear console
  **/
  $("#clear-console").on('click',function(){
      var date = new Date();
      $("#terminal").html('<li><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span><span>Console cleared ...   On '+ date +'</span></li>');
  });


  /**
    * WebSocket
  **/
  /*
  var connect = new ReconnectingWebSocket('ws://' + $("#terminal").attr("data-ip") + ':81/', ['arduino'] , {
    debug: false,
    reconnectInterval: 3000
  });

  connect.onopen = function(event){
    //
    var date = new Date();
    $("#terminal").append('<li class="cyan-text"><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Connected to Smarty server.'+ '   <span class="grey-text">On '+ date +'</span></li>');
  }

  connect.onmessage = function(event){
    alert(event.data);
  }

  connect.onerror = function(event){
    var date = new Date();
    $("#terminal").append('<li class="pink-text"><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Smarty server unavailable.'+ '   <span class="grey-text">On '+ date +'</span></li>');
  }

  connect.onclose = function(event){
    var date = new Date();
    if(event.code != 1000){ //  Connection closed code
      if(!navigator.onLine){
        $("#terminal").append('<li class="red-text"><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Smarty server offline. Check you connection please!'+ '   <span class="grey-text">On '+ date +'</span></li>');
      }else{
        $("#terminal").append('<li class="green-text"><span class="amber-text"><i class="mdi mdi-chevron-double-right"></i>  </span> Connection closed by Smarty server.'+ '   <span class="grey-text">On '+ date +'</span></li>');
      }
    }
  }


  $('.equipment').on('change', function(){
    var gpioState = parseInt($(this).attr('data-state'));
    var gpioPin = parseInt($(this).attr('data-gpio'));
    connect.send('s:' + gpioPin.toString() + ':' + gpioState.toString() + ':');

    gpioState ^= 1 ;
    $(this).attr('data-state',gpioState.toString());

  });
*/
});
